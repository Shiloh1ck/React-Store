const API = 'https://fakestoreapi.com'

export function formatPrice(value) {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(value)
}

export function mapProduct(item) {
  return {
    id: String(item.id),
    name: item.title,
    category: item.category,
    price: item.price,
    description: item.description,
    image: item.image,
    rating: item.rating,
  }
}

async function readJson(response, message) {
  if (!response.ok) {
    throw new Error(message)
  }
  return response.json()
}

export async function fetchProducts() {
  const data = await readJson(
    await fetch(`${API}/products`),
    'Could not load products.',
  )
  return data.map(mapProduct)
}

export async function fetchProduct(id) {
  const data = await readJson(
    await fetch(`${API}/products/${id}`),
    'Could not load this product.',
  )
  if (!data || data.id == null) {
    return null
  }
  return mapProduct(data)
}

export async function fetchCategories() {
  return readJson(
    await fetch(`${API}/products/categories`),
    'Could not load categories.',
  )
}
