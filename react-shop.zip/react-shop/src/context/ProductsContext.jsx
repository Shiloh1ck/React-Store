import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { fetchCategories, fetchProducts } from '../api/store'

const ProductsContext = createContext(null)

export function ProductsProvider({ children }) {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState(['All'])
  const [status, setStatus] = useState('loading')
  const [error, setError] = useState('')

  useEffect(() => {
    let cancelled = false

    Promise.all([fetchProducts(), fetchCategories()])
      .then(([items, names]) => {
        if (cancelled) return
        setProducts(items)
        setCategories(['All', ...names])
        setStatus('ready')
      })
      .catch((err) => {
        if (cancelled) return
        setError(err.message || 'Could not load the catalog.')
        setStatus('error')
      })

    return () => {
      cancelled = true
    }
  }, [])

  const value = useMemo(
    () => ({
      products,
      categories,
      status,
      error,
      getProduct: (id) =>
        products.find((product) => String(product.id) === String(id)),
    }),
    [products, categories, status, error],
  )

  return (
    <ProductsContext.Provider value={value}>{children}</ProductsContext.Provider>
  )
}

export function useProducts() {
  const context = useContext(ProductsContext)
  if (!context) {
    throw new Error('useProducts must be used inside ProductsProvider')
  }
  return context
}
