import { Link } from 'react-router-dom'
import { formatPrice } from '../api/store'
import ProductArt from './ProductArt'

export default function ProductCard({ product }) {
  return (
    <article className="product-card">
      <Link to={`/product/${product.id}`} className="product-card-link">
        <ProductArt product={product} />
        <div className="product-card-meta">
          <p className="eyebrow">{product.category}</p>
          <h3>{product.name}</h3>
          <p className="price">{formatPrice(product.price)}</p>
        </div>
      </Link>
    </article>
  )
}
