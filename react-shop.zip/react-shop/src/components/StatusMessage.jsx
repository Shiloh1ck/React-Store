export default function StatusMessage({ children }) {
  return <p className="lede status-message">{children}</p>
}
