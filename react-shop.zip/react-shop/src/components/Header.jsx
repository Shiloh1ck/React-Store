import { NavLink } from 'react-router-dom'
import { useCart } from '../context/CartContext'

export default function Header() {
  const { count } = useCart()

  return (
    <header className="site-header">
      <NavLink to="/" className="brand">
        Shopify
      </NavLink>
      <nav className="site-nav" aria-label="Primary">
        <NavLink to="/shop">Shop</NavLink>
        <NavLink to="/cart" className="cart-link">
          Cart
          <span className="cart-count">{count}</span>
        </NavLink>
      </nav>
    </header>
  )
}
