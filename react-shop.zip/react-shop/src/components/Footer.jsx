export default function Footer() {
  return (
    <footer className="site-footer">
      <p>Shopify — objects for a slower table.</p>
      <p className="muted">Demo store. Checkout does not process payments.</p>
    </footer>
  )
}
