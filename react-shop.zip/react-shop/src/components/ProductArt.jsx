export default function ProductArt({ product, className = '' }) {
  if (!product?.image) {
    return <div className={`product-art ${className}`} aria-hidden="true" />
  }

  return (
    <div className={`product-art ${className}`}>
      <img src={product.image} alt="" />
    </div>
  )
}
