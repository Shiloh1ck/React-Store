import { Link } from 'react-router-dom'
import ProductCard from '../components/ProductCard'
import StatusMessage from '../components/StatusMessage'
import { useProducts } from '../context/ProductsContext'

export default function Home() {
  const { products, status, error } = useProducts()
  const featured = products.slice(0, 4)

  return (
    <div className="page">
      <section className="hero">
        <p className="eyebrow">Live catalog</p>
        <h1>Quiet objects, made to be used every day.</h1>
        <p className="lede">
          Products are fetched from Fake Store API — clothing, jewelry, and
          electronics, ready for the cart.
        </p>
        <Link to="/shop" className="button">
          Shop the atelier
        </Link>
      </section>

      <section>
        <div className="section-head">
          <h2>In the studio this month</h2>
          <Link to="/shop" className="text-link">
            View all
          </Link>
        </div>
        {status === 'loading' && <StatusMessage>Loading products…</StatusMessage>}
        {status === 'error' && <StatusMessage>{error}</StatusMessage>}
        {status === 'ready' && (
          <div className="product-grid">
            {featured.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </section>
    </div>
  )
}
