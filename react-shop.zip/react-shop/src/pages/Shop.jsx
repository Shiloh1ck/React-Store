import { useMemo, useState } from 'react'
import ProductCard from '../components/ProductCard'
import StatusMessage from '../components/StatusMessage'
import { useProducts } from '../context/ProductsContext'

export default function Shop() {
  const { products, categories, status, error } = useProducts()
  const [category, setCategory] = useState('All')

  const visible = useMemo(
    () =>
      category === 'All'
        ? products
        : products.filter((product) => product.category === category),
    [category, products],
  )

  return (
    <div className="page">
      <header className="page-intro">
        <p className="eyebrow">Catalog</p>
        <h1>The shop</h1>
        <p className="lede">Live inventory from Fake Store API.</p>
      </header>

      <div className="filters" role="tablist" aria-label="Filter by category">
        {categories.map((name) => (
          <button
            key={name}
            type="button"
            role="tab"
            aria-selected={category === name}
            className={category === name ? 'chip is-active' : 'chip'}
            onClick={() => setCategory(name)}
          >
            {name}
          </button>
        ))}
      </div>

      {status === 'loading' && <StatusMessage>Loading products…</StatusMessage>}
      {status === 'error' && <StatusMessage>{error}</StatusMessage>}
      {status === 'ready' && (
        <div className="product-grid">
          {visible.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
