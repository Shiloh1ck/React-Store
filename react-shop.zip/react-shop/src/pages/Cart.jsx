import { Link } from 'react-router-dom'
import ProductArt from '../components/ProductArt'
import { useCart } from '../context/CartContext'
import { formatPrice } from '../api/store'

export default function Cart() {
  const { items, updateQuantity, removeItem, subtotal } = useCart()

  if (items.length === 0) {
    return (
      <div className="page">
        <h1>Cart</h1>
        <p className="lede">Nothing here yet.</p>
        <Link to="/shop" className="button">
          Browse the shop
        </Link>
      </div>
    )
  }

  return (
    <div className="page cart-page">
      <h1>Cart</h1>
      <ul className="cart-list">
        {items.map((item) => (
          <li key={item.id} className="cart-row">
            <ProductArt product={item} className="product-art-thumb" />
            <div className="cart-info">
              <Link to={`/product/${item.id}`}>{item.name}</Link>
              <p className="muted">{formatPrice(item.price)}</p>
            </div>
            <label className="qty">
              Qty
              <input
                type="number"
                min="1"
                value={item.quantity}
                onChange={(event) =>
                  updateQuantity(item.id, Number(event.target.value))
                }
              />
            </label>
            <p className="cart-line">{formatPrice(item.price * item.quantity)}</p>
            <button
              type="button"
              className="text-link"
              onClick={() => removeItem(item.id)}
            >
              Remove
            </button>
          </li>
        ))}
      </ul>
      <div className="cart-summary">
        <p>
          Subtotal <strong>{formatPrice(subtotal)}</strong>
        </p>
        <p className="muted">Shipping calculated at checkout (demo: free).</p>
        <Link to="/checkout" className="button">
          Checkout
        </Link>
      </div>
    </div>
  )
}
