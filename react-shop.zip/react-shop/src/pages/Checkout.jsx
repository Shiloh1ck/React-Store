import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useCart } from '../context/CartContext'
import { formatPrice } from '../api/store'

export default function Checkout() {
  const { items, subtotal, clearCart } = useCart()
  const navigate = useNavigate()
  const [placed, setPlaced] = useState(false)

  if (items.length === 0 && !placed) {
    return (
      <div className="page">
        <h1>Checkout</h1>
        <p className="lede">Your cart is empty.</p>
        <Link to="/shop" className="button">
          Shop first
        </Link>
      </div>
    )
  }

  if (placed) {
    return (
      <div className="page">
        <p className="eyebrow">Order received</p>
        <h1>Thank you.</h1>
        <p className="lede">
          This is a demo store — no payment was taken and nothing will ship.
        </p>
        <Link to="/shop" className="button">
          Continue browsing
        </Link>
      </div>
    )
  }

  const handleSubmit = (event) => {
    event.preventDefault()
    clearCart()
    setPlaced(true)
    navigate('/checkout', { replace: true })
  }

  return (
    <div className="page checkout-page">
      <div>
        <h1>Checkout</h1>
        <form className="checkout-form" onSubmit={handleSubmit}>
          <label>
            Full name
            <input name="name" required autoComplete="name" />
          </label>
          <label>
            Email
            <input name="email" type="email" required autoComplete="email" />
          </label>
          <label>
            Address
            <input name="address" required autoComplete="street-address" />
          </label>
          <div className="form-row">
            <label>
              City
              <input name="city" required autoComplete="address-level2" />
            </label>
            <label>
              Postal code
              <input name="postal" required autoComplete="postal-code" />
            </label>
          </div>
          <button type="submit" className="button">
            Place order
          </button>
        </form>
      </div>
      <aside className="order-summary">
        <h2>Order</h2>
        <ul>
          {items.map((item) => (
            <li key={item.id}>
              <span>
                {item.name} × {item.quantity}
              </span>
              <span>{formatPrice(item.price * item.quantity)}</span>
            </li>
          ))}
        </ul>
        <p className="total">
          Total <strong>{formatPrice(subtotal)}</strong>
        </p>
      </aside>
    </div>
  )
}
