import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { fetchProduct, formatPrice } from '../api/store'
import ProductArt from '../components/ProductArt'
import StatusMessage from '../components/StatusMessage'
import { useCart } from '../context/CartContext'
import { useProducts } from '../context/ProductsContext'

export default function Product() {
  const { id } = useParams()
  const { getProduct } = useProducts()
  const fromCatalog = getProduct(id)
  const { addItem } = useCart()
  const [product, setProduct] = useState(fromCatalog ?? null)
  const [status, setStatus] = useState(fromCatalog ? 'ready' : 'loading')
  const [error, setError] = useState('')
  const [added, setAdded] = useState(false)

  useEffect(() => {
    if (fromCatalog) {
      setProduct(fromCatalog)
      setStatus('ready')
      return
    }

    let cancelled = false
    setStatus('loading')
    setError('')

    fetchProduct(id)
      .then((item) => {
        if (cancelled) return
        if (!item) {
          setProduct(null)
          setStatus('missing')
          return
        }
        setProduct(item)
        setStatus('ready')
      })
      .catch((err) => {
        if (cancelled) return
        setError(err.message || 'Could not load this product.')
        setStatus('error')
      })

    return () => {
      cancelled = true
    }
  }, [id, fromCatalog])

  const handleAdd = () => {
    addItem(product)
    setAdded(true)
    window.setTimeout(() => setAdded(false), 1600)
  }

  if (status === 'loading') {
    return (
      <div className="page">
        <StatusMessage>Loading product…</StatusMessage>
      </div>
    )
  }

  if (status === 'error') {
    return (
      <div className="page">
        <h1>Could not load</h1>
        <StatusMessage>{error}</StatusMessage>
        <Link to="/shop" className="button">
          Back to shop
        </Link>
      </div>
    )
  }

  if (status === 'missing' || !product) {
    return (
      <div className="page">
        <h1>Not found</h1>
        <p>That piece is no longer in the shop.</p>
        <Link to="/shop" className="button">
          Back to shop
        </Link>
      </div>
    )
  }

  return (
    <div className="page product-page">
      <ProductArt product={product} className="product-art-large" />
      <div className="product-copy">
        <p className="eyebrow">{product.category}</p>
        <h1>{product.name}</h1>
        <p className="price">{formatPrice(product.price)}</p>
        <p className="lede">{product.description}</p>
        {product.rating && (
          <p className="muted">
            Rated {product.rating.rate} / 5 ({product.rating.count} reviews)
          </p>
        )}
        <button type="button" className="button" onClick={handleAdd}>
          {added ? 'Added to cart' : 'Add to cart'}
        </button>
      </div>
    </div>
  )
}
